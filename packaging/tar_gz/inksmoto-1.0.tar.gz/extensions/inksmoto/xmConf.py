SVG2LVL_RATIO = 0.05
enableRecording = False
ENTITY_RADIUS = {'Flower': 0.5, 'Sprite': 0.40000000000000002, 'Strawberry': 0.5, 'PlayerStart': 0.40000000000000002, 'EndOfLevel': 0.5, 'Joint': 0.5, 'ParticleSource': 0.40000000000000002, 'Wrecker': 0.40000000000000002, 'Checkpoint': 0.4}
recordingSession = ''
currentTest = 0
