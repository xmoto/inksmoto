#!/bin/python3
"""
Copyright (C) 2006,2009 Emmanuel Gorse, e.gorse@gmail.com
"""

import logging
from gi.repository import Gtk, Gdk, GdkPixbuf
from .xmotoExtension import XmExt
from .defaultValues import DefaultValues
from .xmotoTools import createIfAbsent, applyOnElements, delWoExcept
from .xmotoTools import getExistingImageFullPath, conv8to16, conv16to8
from .xmotoTools import setOrDelBool, setOrDelValue, setOrDelColor, getValue
from .xmotoTools import setOrDelBitmap, getIndexInList
from .inkex import addNS
from .parsers import LabelParser
from . import xmGuiGtk
from inksmoto.availableElements import AvailableElements
from .testsCreator import TestsCreator
from inksmoto.confGenerator import Conf
from os.path import exists

class WidgetInfos:
    def __init__(self, ns, key, default=None, accessors=None,
                 items=None, dontDel=False):
        self.ns = ns
        self.key = key
        self.default = default
        self.accessors = accessors
        self.items = items
        self.dontDel = dontDel

    def get(self):
        return (self.ns, self.key, self.default, self.accessors,
                self.items, self.dontDel)

class XmExtGtk(XmExt):
    def __init__(self):
        super().__init__()
        self.widgets = {}

    def createWindow(self, okFunc):
        def addLog(command, widget, buttonCmd):
            if Conf()['enableRecording']:
                TestsCreator().addGtkCmd(buttonCmd)
            command(widget)

        (gladeFile, self.windowName) = self.getWindowInfos()
        self.wTree = xmGuiGtk.createWindow(gladeFile, self.windowName)
        window = self.get(self.windowName)
        window.connect("destroy", xmGuiGtk.quit)

        _dic = {"on_apply_clicked": lambda widget:
                    addLog(okFunc, widget, "self.get('apply').clicked()"),
                "on_cancel_clicked": lambda widget:
                    addLog(xmGuiGtk.quit, widget, "self.get('cancel').clicked()")}
        self.wTree.signal_autoconnect(_dic)

        self.widgetsInfos = self.getWidgetsInfos()
        if self.widgetsInfos is not None:
            if self.recording:
                self.addTraces(self.widgetsInfos)

            self.fillWindowValues(self.widgetsInfos)

        signals = self.getSignals()
        if signals is not None:
            self.registerSignals(signals)
    def mainLoop(self):
        from . import testcommands
        if len(testcommands.testCommands) != 0:
            for cmd in testcommands.testCommands:
                exec(cmd)
            # has Gtk.main() has not been called, Gtk.main_quit()
            # doesn’t work for destroying the window. destroy it manually
            self.get(self.windowName).destroy()
        else:
            xmGuiGtk.mainLoop()

    def addWidget(self, widgetName, widget):
        self.widgets[widgetName] = widget

    def get(self, widgetName):
        widget = self.wTree.get_widget(widgetName)
        if widget is None and widgetName in self.widgets:
            widget = self.widgets[widgetName]
        return widget

    def registerSignals(self, signals):
        for signal, func in signals.items():
            self.wTree.signal_connect(signal, func)

    def fillWindowValues(self, values):
        """ get a dict with 'widgetName': (ns, key, default,
            accessors). For each widget in the dict, get the value
            from the svg and set it to the widget
        """
        for widgetName, widgetInfos in values.items():
            (ns, key, default, accessors, items, dontDel) = widgetInfos.get()
            value = self.getValue(ns, key, default)
            widget = self.get(widgetName)

            if isinstance(widget, Gtk.CheckButton):
                widget.set_active(value == 'true')
            elif isinstance(widget, Gtk.Scale):
                if value is not None:
                    if accessors is not None:
                        setter, _ = accessors
                        value = setter(float(value))
                    widget.set_value(float(value))
            elif isinstance(widget, Gtk.Button):
                label = self.get(widgetName + 'Label')
                if label is not None:
                    imgName = value
                    bitmapDict = None
                    img = None
                    for type_ in ['TEXTURES', 'EDGETEXTURES', 'PARTICLESOURCES', 'SPRITES']:
                        try:
                            bitmapDict = AvailableElements()[type_]
                            img = bitmapDict[imgName]['file']
                        except KeyError:
                            pass
                        else:
                            break
                    if img is not None:
                        xmGuiGtk.addImgToBtn(widget, label, imgName, bitmapDict)
            elif isinstance(widget, Gtk.ColorButton):
                r = self.getValue(ns, key + '_r', default)
                g = self.getValue(ns, key + '_g', default)
                b = self.getValue(ns, key + '_b', default)
                a = self.getValue(ns, key + '_a', default)
                widget.set_rgba(Gdk.RGBA(float(r) / 255.0, float(g) / 255.0, float(b) / 255.0, float(a) / 255.0))
            elif isinstance(widget, Gtk.Entry):
                widget.set_text(value)
            elif isinstance(widget, Gtk.FileChooserButton):
                if exists(value):
                    widget.set_filename(value)
            elif isinstance(widget, Gtk.ComboBox):
                listStore = Gtk.ListStore(str)
                widget.set_model(listStore)
                cell = Gtk.CellRendererText()
                widget.pack_start(cell, True)
                widget.add_attribute(cell, 'text', 0)

                for item in items:
                    widget.append_text(item)
                selection = getIndexInList(items, value)
                widget.set_active(selection)
    def fillResults(self, dict_):
        if self.widgetsInfos is None:
            return

        self.fillResultsPreHook()

        for widgetName in list(self.widgetsInfos.keys()):
            widget = self.get(widgetName)
            (ns, key, default, accessors, items, dontDel) = self.widgetsInfos[widgetName].get()
            createIfAbsent(dict_, ns)

            if isinstance(widget, Gtk.CheckButton):
                bool_ = widget.get_active()
                self.setOrDelBool(ns, key, bool_, dontDel)
            elif isinstance(widget, Gtk.Scale):
                value = widget.get_value()
                if accessors is not None:
                    _, getter = accessors
                    value = getter(value)
                self.setOrDelValue(ns, key, value, default)
            elif isinstance(widget, Gtk.Button):
                label = self.get(widgetName + 'Label')
                if label is not None:
                    bitmap = label.get_text()
                    self.setOrDelBitmap(ns, key, bitmap)
            elif isinstance(widget, Gtk.ColorButton):
                color = widget.get_rgba()
                (r, g, b, a) = (int(color.red * 255),
                                int(color.green * 255),
                                int(color.blue * 255),
                                int(color.alpha * 255))
                self.setOrDelColor(ns, key, (r, g, b, a))
            elif isinstance(widget, Gtk.Entry):
                text = widget.get_text()
                self.setOrDelValue(ns, key, text, default)
            elif isinstance(widget, Gtk.FileChooserButton):
                fileName = widget.get_filename()
                self.setOrDelValue(ns, key, fileName, default)
            elif isinstance(widget, Gtk.ComboBox):
                music = widget.get_active_text()
                self.setOrDelValue(ns, key, music, default)

        self.removeUnusedNs(dict_)

    def removeUnusedNs(self, dict_):
        toDel = []
        for ns in dict_.keys():
            if dict_[ns] == {}:
                toDel.append(ns)
        for ns in toDel:
            del dict_[ns]

    def addTraces(self, widgets):
        def _log(f, widgetName, paramType):
            def __log(*args, **kw):
                ret = f(*args, **kw)
                logger(f, widgetName, paramType, args, kw, ret)
                return ret
            return __log

        logger = traceCalls

        for widgetName, widgetInfos in widgets.items():
            (ns, key, default, accessors, items, dontDel) = widgetInfos.get()
            widget = self.get(widgetName)
            if isinstance(widget, Gtk.CheckButton):
                get_active = getattr(widget, 'get_active')
                setattr(widget, 'get_active',
                        _log(get_active, widgetName, paramType=bool))
            elif isinstance(widget, Gtk.Scale):
                get_value = getattr(widget, 'get_value')
                setattr(widget, 'get_value',
                        _log(get_value, widgetName, paramType=float))
            elif isinstance(widget, Gtk.Button):
                labelName = widgetName + 'Label'
                label = self.get(labelName)
                if label is not None:
                    get_text = getattr(label, 'get_text')
                    setattr(label, 'get_text',
                            _log(get_text, labelName, paramType=str))
            elif isinstance(widget, Gtk.ColorButton):
                get_rgba = getattr(widget, 'get_rgba')
                setattr(widget, 'get_rgba',
                        _log(get_rgba, widgetName, paramType=Gdk.RGBA))
            elif isinstance(widget, Gtk.Entry):
                get_text = getattr(widget, 'get_text')
                setattr(widget, 'get_text',
                        _log(get_text, widgetName, paramType=str))
            elif isinstance(widget, Gtk.FileChooserButton):
                get_filename = getattr(widget, 'get_filename')
                setattr(widget, 'get_filename',
                        _log(get_filename, widgetName, paramType=str))
            elif isinstance(widget, Gtk.ComboBox):
                get_active = getattr(widget, 'get_active')
                setattr(widget, 'get_active',
                        _log(get_active, widgetName, paramType=int))
