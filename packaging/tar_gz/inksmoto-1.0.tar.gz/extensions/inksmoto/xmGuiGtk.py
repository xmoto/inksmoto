#!/bin/python3
"""
Copyright (C) 2006,2009 Emmanuel Gorse, e.gorse@gmail.com
"""

from gi.repository import Gtk, GdkPixbuf, Gdk
import logging
import sys

from os.path import join, exists
from .xmotoTools import getSystemDir, getExistingImageFullPath
from .xmotoTools import alphabeticSortOfKeys, getHomeDir
from .availableElements import AvailableElements

TEXTURES = AvailableElements()['TEXTURES']
EDGETEXTURES = AvailableElements()['EDGETEXTURES']
SPRITES = AvailableElements()['SPRITES']
PARTICLESOURCES = AvailableElements()['PARTICLESOURCES']

EDGETEXTURES['_None_'] = {'file':'none.png'}
TEXTURES['_None_'] = {'file':'none.png'}
SPRITES['_None_'] = {'file':'none.png'}

def quit(widget=None):
    """ the widget param is present when called from a gtk signal."""
    Gtk.main_quit()

def mainLoop():
    Gtk.main()

def errorMessageBox(msg):
    dlg = Gtk.MessageDialog(parent=None, flags=Gtk.DialogFlags.MODAL,
                            type=Gtk.MessageType.ERROR, buttons=Gtk.ButtonsType.CLOSE,
                            message_format=msg)
    dlg.run()
    dlg.destroy()

def createWindow(gladeFile, windowName):
    pass

def addImgToBtn(button, label, imgName, bitmapDict):
    imgFile = bitmapDict[imgName]['file']
    imgFullFile = getExistingImageFullPath(imgFile)

    if imgFullFile is None:
        logging.warning("xmGuiGtk::addImgToBtn no image full path for %s: %s" % (imgName, imgFile))
        imgFile = '__missing__.png'
        imgFullFile = getExistingImageFullPath(imgFile)

    img = Gtk.Image()
    pixBuf = GdkPixbuf.Pixbuf.new_from_file(imgFullFile)
    img.set_from_pixbuf(pixBuf)

    button.set_image(img)
    label.set_text(imgName)

    img.show()

def resetColor(button):
    button.override_background_color(Gtk.StateFlags.NORMAL, Gdk.RGBA(1, 1, 1, 1))
    button.set_opacity(1.0)

class BitmapSelectWindow:
    def __init__(self, title, bitmaps):
        self.selectedImage = None

        wTree = createWindow('bitmapSelection.glade', 'bitmapSelection')
        self.window = wTree.get_widget('bitmapSelection')
        self.window.set_title(title)
        self.window.connect("destroy", Gtk.main_quit)

        self.keys = alphabeticSortOfKeys(list(bitmaps.keys()))

        store = Gtk.ListStore(str, GdkPixbuf.Pixbuf)
        store.clear()

        # skip the __biker__.png image used for PlayerStart
        self.keys = [key for key in self.keys if bitmaps[key]['file'][0:2] != '__']

        for name in self.keys:
            try:
                imgFile = bitmaps[name]['file']
                imgFullFile = getExistingImageFullPath(imgFile)
                if imgFullFile is None:
                    imgFile = '__missing__.png'
                    imgFullFile = getExistingImageFullPath(imgFile)
                pixBuf = GdkPixbuf.Pixbuf.new_from_file(imgFullFile)

                store.append([name, pixBuf])

            except Exception as e:
                logging.info("Can't create bitmap for %s\n%s" % (name, e))
                store.append([name, None])

        iconView = wTree.get_widget('bitmapsView')
        iconView.set_model(store)
        iconView.set_text_column(0)
        iconView.set_pixbuf_column(1)
        iconView.connect("item-activated", self.bitmapSelected)

    def run(self):
        self.window.show_all()
        Gtk.main()
        return self.selectedImage

    def bitmapSelected(self, iconView, imageIdx):
        self.selectedImage = self.keys[imageIdx.get_indices()[0]]
        self.window.destroy()
        Gtk.main_quit()
